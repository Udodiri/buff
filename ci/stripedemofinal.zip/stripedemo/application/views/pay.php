

<?php

	header('location: '.$pay_url);

	 ?>