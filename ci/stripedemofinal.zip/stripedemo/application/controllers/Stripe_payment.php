<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Stripe_payment extends CI_Controller {
 
	public function __construct() {
 
		parent::__construct();
 
		}
 
          public function index()
         {	
         	//$data['pay_url'] = "https://connect.stripe.com/oauth/authorize?response_type=code&client_id=ca_9MSmI571aMlM4OghKXM8xUyJ4mSFuFKK&scope=read_write";	
             $this->load->view('index');
          }
 
	public function checkout()
	{  

		
		try {
                    
			require_once(APPPATH.'libraries/Stripe/lib/Stripe.php');//or you
			//Stripe::setApiKey("sk_test_rZzdFupalVZsMFbnM2PoYloA"); //Replace with your Secret Key
 
 			//Stripe::setApiKey("sk_test_rZzdFupalVZsMFbnM2PoYloA");
			Stripe::setApiKey($_POST['access_token']);


 			
			// $charge = Stripe_Charge::create(array(
			// 	"amount" => 2500,
			// 	"currency" => "usd",
			// 	"card" => $_POST['stripeToken'],
			// 	"description" => "Demo Transaction"
			// ));

// Get the credit card details submitted by the form
         if(isset($_POST['stripeToken'])){$token = $_POST['stripeToken'];}else{$token ="";}
 	// 	if(isset($_POST['access_token'])){$token = $_POST['access_token'];}else{$token ="";}
  //       echo $token;

		// Stripe_Customer::create(
		//   array("description" => "deepaks.snv@gmail.com"),
		//   array("stripe_account" => "sk_test_fxrfl2VOCwBNAUncU1H9Tu1X")
		// );

		// // Fetching an account just needs the ID as a parameter
		// $user = Stripe_Account::retrieve("sk_test_fxrfl2VOCwBNAUncU1H9Tu1X");
		// echo "<Pre>";


		// $array =  (array) $user;
		// $arrayName = array();
		// foreach ($array as $key => $value) {
		// $arrayName[]=$value;
		// 	# code...
		// }

		// $acc_id = $arrayName[1]['id'];
       
		// print_r($arrayName);

		// echo $arrayName[1]['id'];
		// die;

		// Create the charge with Stripe
		$charge = Stripe_Charge::create(
		  array(
		    "amount" => 400, // amount in cents
		    "currency" => "usd",
		    "source" => $token,     /// replace source with card
		    "description" => "Example charge",
		    "application_fee" => 300 // amount in cents
		   // 'destination' => $acc_id // CONNECTED_STRIPE_ACCOUNT_ID
		  ),
		  		   array("stripe_account" => "dev.sunilbhawsar@gmail.com")
		);


	echo "<h1>Your payment has been completed.</h1><pre>";	
     	
	   $result  =  (array) $charge;
		echo "<Pre>";
		print_r($result);
		die;

		}
 
		catch(Stripe_CardError $e) {
 		$error1 = $e->getMessage();
 		echo "error1";
 		var_dump($error1);
		}
		catch (Stripe_InvalidRequestError $e) {
 		$error2 = $e->getMessage();
 		echo "error2";
 		var_dump($error2);
		} catch (Stripe_AuthenticationError $e) {
			echo "error3";
			$error3 = $e->getMessage();
 		var_dump($error3);
		} catch (Stripe_ApiConnectionError $e) {
			echo "error4";
			$error4 = $e->getMessage();
 		var_dump($error4);
		} catch (Stripe_Error $e) {
			echo "error5";
			$error5 = $e->getMessage();
 		var_dump($error5);
		} catch (Exception $e) {
			echo "error6";
			$error6 = $e->getMessage();
 		var_dump($error6);
		}
	}
 
}