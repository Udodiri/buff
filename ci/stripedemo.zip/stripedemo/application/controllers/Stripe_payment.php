<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Stripe_payment extends CI_Controller {
 
	public function __construct() {
 
		parent::__construct();
 
		}
 
          public function index()
         {
             $this->load->view('index');
          }
 
	public function checkout()
	{

		
		try {
                    
			require_once(APPPATH.'libraries/Stripe/lib/Stripe.php');//or you
			Stripe::setApiKey("sk_test_rZzdFupalVZsMFbnM2PoYloA"); //Replace with your Secret Key
 
			// $charge = Stripe_Charge::create(array(
			// 	"amount" => 2500,
			// 	"currency" => "usd",
			// 	"card" => $_POST['stripeToken'],
			// 	"description" => "Demo Transaction"
			// ));

// Get the credit card details submitted by the form
        $token = $_POST['stripeToken'];

// Create the charge with Stripe
$charge = Stripe_Charge::create(
  array(
    "amount" => 5000, // amount in cents
    "currency" => "usd",
    "card" => $token,     /// replace source with card
    "description" => "Example charge",
    "application_fee" => 3000 // amount in cents
  ),
  array("stripe_account" => "deepaks.snv@gmail.com")
);





			// $account_ids = array("0"=>"snv.ankit@gmail.com","1"=>"deepak.sharma@snvinfotech.com");
   
			//    foreach($account_ids as $acc_id){
			//     $res =     Stripe_Transfer::create(array(
			//  'amount' =>2100,
			//  'currency' => "usd",
			//  'destination' => $acc_id
			// ));
			// echo "<Pre> response";    
			// var_dump($res);   

			//  }
						echo "<h1>Your payment has been completed.</h1><pre>";	
                        var_dump($charge);
		}
 
		catch(Stripe_CardError $e) {
 
		}
		catch (Stripe_InvalidRequestError $e) {
 
		} catch (Stripe_AuthenticationError $e) {
		} catch (Stripe_ApiConnectionError $e) {
		} catch (Stripe_Error $e) {
		} catch (Exception $e) {
		}
	}
 
}